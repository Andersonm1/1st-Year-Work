#!/usr/bin/python3
import cgi , cgitb
cgitb.enable()
form = cgi.FieldStorage()
year = form.getvalue("current_year")
mode = form.getvalue("type")
months = ["March", "April"]
try:
    year = int(year)
except ValueError:
    year = 2020


def easter_alg(current_year):
    a = current_year % 19
    b = current_year // 100
    c = current_year % 100
    d = b // 4
    e = b % 4
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    j = c // 4
    k = c % 4
    m = (a + 11 * h) // 319
    r = (2 * e + 2 * j - k - h + m + 32) % 7
    month = (h - m + r + 90) // 25
    day = (h - m + r + month + 19) % 32
    print_date(day, month, current_year)

def change_to_word(day, month):
    month -= 3
    month_1 = months[month]
    day = int(day)
    if day == 2 or day == 22:
        suffix = "nd"
    elif day == 1 or day == 21 or day == 31:
        suffix = "st"
    elif day == 3 or day == 23:
        suffix = "rd"
    else:
        suffix = "th"
    return month_1, suffix

def print_digital(day, month, year):
    month = str(month)
    year = str(year)
    print(' Easter Sunday falls on %s / %s / %s' %(day, month, year))
    print(' </p>')
def print_analogue(day, month, year):
    month_1, suffix = change_to_word(day, month)
    month_1 = str(month_1)
    year = str(year)
    print(' Easter Sunday falls on %s<sup>%s</sup> %s %s' %(day, suffix, month_1, year))
    print(' </p>')

def print_date(day, month, year):
    day = str(day)
    print('Content-Type: text/html; charset=utf-8')
    print('')
    print('<!DOCTYPE html>')
    print('<html>')
    print('<head>')
    print('<meta charset="UTF-8" />')
    print('<title>CGI for coursework</title>')
    print('<link rel="stylesheet" href="../Style_2.css" />')
    print('</head>')
    print('<body>')
    print('<p>')
    if mode == "digital":
        print_digital(day, month, year)
    elif mode == "analogue":
        print_analogue(day, month, year)
    else:
        print_digital(day, month, year)
        print('<p>')
        print_analogue(day, month, year)
    print('<a href="../Page_1.html"><button>Back</button></a>')
    print('</body>')
    print('</html>')


easter_alg(year)
